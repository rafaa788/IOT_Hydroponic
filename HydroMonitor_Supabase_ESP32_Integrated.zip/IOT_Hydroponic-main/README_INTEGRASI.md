# HydroMonitor - Integrasi ESP32 + Supabase

## Isi paket
- `index.html`: website HydroMonitor dengan tampilan asli dipertahankan, data sensor dibaca dari Supabase, grafik pH dari histori, kontrol Pompa 1 dan Pompa 2.
- `supabase_setup.sql`: struktur tabel dan policy demo.
- `esp32_firmware/HydroMonitor_ESP32.ino`: firmware ESP32.
- `esp32_firmware/secrets.h.example`: template kredensial Wi-Fi dan Supabase. Salin menjadi `secrets.h` dan isi sendiri.

## Pin kerja berdasarkan diagram Cirkit yang dikirim
| Komponen | GPIO ESP32 |
|---|---:|
| Output analog pH | 34 |
| Output analog TDS | 35 |
| DHT22 DATA | 15 |
| HC-SR04 TRIG | 26 |
| HC-SR04 ECHO | 27 |
| Relay IN1 / Pompa 1 | 18* |
| Relay IN2 / Pompa 2 | 19* |

`*` Jalur relay pada gambar perlu dicocokkan lagi dengan label IN1/IN2 di proyek Cirkit sebelum diberi daya. GPIO18/19 dipakai sebagai pemetaan firmware awal.

## Cara memasang
1. Buka Supabase SQL Editor dan jalankan seluruh `supabase_setup.sql`.
2. Pastikan tabel `sensor_readings` dan `device_commands` muncul. Baris `device_id = hydro-01` harus tersedia.
3. Buka folder firmware di Arduino IDE. Pasang library `DHT sensor library` (Adafruit) dan `ArduinoJson` versi 7. Library WiFi/HTTPClient tersedia bersama ESP32 Arduino Core.
4. Salin `secrets.h.example` menjadi `secrets.h`, isi SSID/password Wi-Fi dan publishable key. Jangan unggah password Wi-Fi ke GitHub publik.
5. Periksa kembali pin relay, polaritas relay aktif LOW/HIGH, pembagi tegangan Echo dan keluaran analog sensor.
6. Upload firmware ke ESP32, buka Serial Monitor 115200 baud.
7. Jalankan `index.html` melalui hosting HTTPS (misalnya GitHub Pages). Jangan hanya membuka `file://` bila browser memblokir fetch.

## Sensor yang ditampilkan
Rangkaian pada gambar menunjukkan pH, TDS, DHT22, dan HC-SR04. Karena tidak tampak DS18B20 atau BH1750, kartu suhu air dan cahaya tidak ditampilkan sebagai data sensor. Suhu/kelembapan udara berasal dari DHT22. Level air adalah perkiraan berdasarkan jarak HC-SR04 dan `TANK_HEIGHT_CM`.

## Kalibrasi wajib
- `PH_SLOPE` dan `PH_OFFSET` adalah nilai awal perkiraan. Kalibrasikan menggunakan larutan buffer pH 4.00 dan 7.00.
- `TDS_CALIBRATION` perlu disesuaikan dengan larutan standar TDS. Rumus EC/TDS bergantung pada karakteristik modul dan tegangan output.
- Atur `TANK_HEIGHT_CM` sesuai jarak sensor ke dasar tandon dan posisi sensor sebenarnya.
- Suhu DHT22 dipakai sebagai pendekatan kompensasi TDS karena rangkaian tidak menunjukkan sensor suhu air. Untuk hasil lebih akurat tambahkan DS18B20.

## Keamanan Supabase
SQL ini menggunakan policy anon terbuka untuk prototipe sehingga website dan ESP32 dapat langsung berkomunikasi. Artinya siapa pun yang mengetahui project URL dan publishable key dapat membaca data dan mengubah perintah pompa. Untuk pemakaian publik, pindahkan kontrol perintah ke Supabase Edge Function dengan autentikasi/device secret dan batasi policy RLS. Publishable key bukan secret key.

## Catatan keselamatan listrik
Jangan hubungkan pompa 12V ke pin ESP32. Pompa harus mendapat catu 12V melalui kontak relay yang sesuai rating, dengan ground dan isolasi sesuai rancangan. Pastikan tegangan modul relay cocok dengan catu dan jangan menguji sambungan listrik bertegangan tinggi tanpa isolasi/proteksi yang benar. Echo HC-SR04 5V harus diturunkan ke 3.3V sebelum GPIO27. Ukur keluaran analog modul pH/TDS; jangan biarkan ADC ESP32 menerima lebih dari 3.3V.
