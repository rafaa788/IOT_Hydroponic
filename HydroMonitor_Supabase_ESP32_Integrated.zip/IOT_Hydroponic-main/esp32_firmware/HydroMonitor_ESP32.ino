/*
  HydroMonitor - ESP32 DevKit V1
  Sensor sesuai rangkaian Cirkit Designer:
  pH analog -> GPIO34, TDS analog -> GPIO35
  DHT22 DATA -> GPIO15
  HC-SR04 TRIG -> GPIO26, ECHO -> GPIO27
  Relay 2 channel IN1 -> GPIO18 (Pompa 1), IN2 -> GPIO19 (Pompa 2)

  CATATAN: GPIO18/19 untuk IN1/IN2 dibaca dari jalur rangkaian sebagai
  pemetaan kerja. Cocokkan sekali lagi dengan label pin IN1/IN2 di Cirkit.
  Relay module umumnya aktif LOW; ubah RELAY_ACTIVE_LOW bila modul berbeda.
  Jangan sambungkan Echo HC-SR04 5V langsung ke GPIO ESP32: gunakan divider.
  Pastikan output analog modul pH/TDS <= 3.3V sebelum masuk ADC ESP32.

  Library: DHT sensor library (Adafruit), ArduinoJson v7
*/
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <DHT.h>
#include <ArduinoJson.h>
#include <time.h>
#include "secrets.h" // WIFI_SSID, WIFI_PASS, SUPABASE_URL, SUPABASE_ANON_KEY

#define DEVICE_ID "hydro-01"
#define PIN_PH       34
#define PIN_TDS      35
#define PIN_DHT      15
#define PIN_TRIG     26
#define PIN_ECHO     27
#define PIN_PUMP1    18
#define PIN_PUMP2    19
#define DHT_TYPE DHT22
#define RELAY_ACTIVE_LOW true

const unsigned long SEND_INTERVAL_MS = 10000;
const unsigned long COMMAND_INTERVAL_MS = 3000;
const float TANK_HEIGHT_CM = 30.0; // ukur tinggi efektif dari sensor ke dasar tandon
const float PH_SLOPE = -5.70;      // wajib kalibrasi buffer pH 4 dan 7
const float PH_OFFSET = 21.25;     // nilai awal perkiraan, bukan kalibrasi final
const float TDS_CALIBRATION = 1.0; // koreksi setelah dibandingkan larutan standar

DHT dht(PIN_DHT, DHT_TYPE);
unsigned long lastSend=0, lastCommand=0, sprayEnd=0, lastAuto=0;
long lastSprayId=-1;
bool autoMode=true, schedPagi=true, schedSiang=true, schedSore=true;
bool pump1Running=false, pump2Running=false;
int sprayIntervalMin=30, sprayDefaultSec=4;

void relayWrite(uint8_t pin, bool on) {
  bool level = RELAY_ACTIVE_LOW ? !on : on;
  digitalWrite(pin, level ? HIGH : LOW);
}
float readVoltageAverage(uint8_t pin) {
  uint32_t sum=0;
  for(int i=0;i<24;i++){ sum += analogRead(pin); delay(3); }
  float raw=sum/24.0f;
  return raw * 3.3f / 4095.0f;
}
float readPH() {
  float v=readVoltageAverage(PIN_PH);
  return PH_SLOPE*v + PH_OFFSET;
}
float readTdsPpm(float airTempC) {
  float v=readVoltageAverage(PIN_TDS);
  // Kompensasi suhu awal menggunakan suhu udara DHT sebagai pendekatan.
  // Untuk akurasi lebih baik, pasang sensor suhu air DS18B20.
  float compensation = 1.0f + 0.02f*(airTempC-25.0f);
  float cv = v / compensation;
  float ppm = (133.42f*cv*cv*cv - 255.86f*cv*cv + 857.39f*cv)*0.5f;
  return max(0.0f, ppm*TDS_CALIBRATION);
}
float readWaterLevelPct() {
  digitalWrite(PIN_TRIG,LOW); delayMicroseconds(3);
  digitalWrite(PIN_TRIG,HIGH); delayMicroseconds(10);
  digitalWrite(PIN_TRIG,LOW);
  unsigned long duration=pulseIn(PIN_ECHO,HIGH,30000UL);
  if(duration==0) return NAN;
  float distance=duration*0.0343f/2.0f;
  return constrain((1.0f-distance/TANK_HEIGHT_CM)*100.0f,0.0f,100.0f);
}
void addAuth(HTTPClient &http) {
  http.addHeader("apikey",SUPABASE_ANON_KEY);
  http.addHeader("Authorization",String("Bearer ")+SUPABASE_ANON_KEY);
}
void sendReading() {
  float airTemp=dht.readTemperature();
  float humidity=dht.readHumidity();
  if(isnan(airTemp)) airTemp=25.0f; // hanya untuk kompensasi TDS; tidak dikirim sebagai bacaan palsu
  JsonDocument doc;
  doc["device_id"]=DEVICE_ID;
  doc["ph"]=readPH();
  doc["ec_ppm"]=readTdsPpm(airTemp);
  float level=readWaterLevelPct();
  if(!isnan(level)) doc["water_level_pct"]=level;
  if(!isnan(dht.readTemperature())) doc["air_temp_c"]=dht.readTemperature();
  if(!isnan(humidity)) doc["humidity_pct"]=humidity;
  String body; serializeJson(doc,body);
  WiFiClientSecure client; client.setInsecure(); // gunakan CA certificate untuk deployment produksi
  HTTPClient http;
  String url=String(SUPABASE_URL)+"/rest/v1/sensor_readings";
  if(http.begin(client,url)){
    addAuth(http); http.addHeader("Content-Type","application/json");
    http.addHeader("Prefer","return=minimal");
    int code=http.POST(body);
    Serial.printf("Sensor POST %d: %s\n",code,body.c_str());
    if(code<200 || code>=300) Serial.println(http.getString());
    http.end();
  }
}
void setPump1(bool on){ pump1Running=on; relayWrite(PIN_PUMP1,on); }
void setPump2(bool on){ pump2Running=on; relayWrite(PIN_PUMP2,on); }
void startPump1For(int seconds){
  if(seconds<=0){setPump1(false);return;}
  setPump1(true); sprayEnd=millis()+(unsigned long)seconds*1000UL;
  Serial.printf("Pompa 1 ON %d detik\n",seconds);
}
void pollCommands(){
  WiFiClientSecure client; client.setInsecure();
  HTTPClient http;
  String url=String(SUPABASE_URL)+"/rest/v1/device_commands?device_id=eq."+DEVICE_ID+"&select=*&limit=1";
  if(!http.begin(client,url)) return;
  addAuth(http);
  int code=http.GET();
  if(code==200){
    JsonDocument doc;
    DeserializationError err=deserializeJson(doc,http.getString());
    if(!err && doc.is<JsonArray>() && doc.size()>0){
      JsonObject c=doc[0];
      autoMode=c["auto_mode"]|true;
      schedPagi=c["sched_pagi"]|true; schedSiang=c["sched_siang"]|true; schedSore=c["sched_sore"]|true;
      sprayIntervalMin=constrain((int)(c["spray_interval_min"]|30),1,1440);
      sprayDefaultSec=constrain((int)(c["spray_default_s"]|4),1,600);
      setPump2(c["pump2_on"]|false);
      long id=c["spray_id"]|0L; int duration=constrain((int)(c["spray_duration_s"]|0),0,600);
      if(lastSprayId<0) lastSprayId=id;
      else if(id!=lastSprayId){lastSprayId=id;startPump1For(duration);}
    }
  } else { Serial.printf("Command GET error %d\n",code); }
  http.end();
}
void autoPumpSchedule(){
  if(!autoMode || pump1Running) return;
  struct tm t;
  if(!getLocalTime(&t,50)) return;
  int h=t.tm_hour;
  bool inWindow=(schedPagi&&h>=6&&h<10)||(schedSiang&&h>=10&&h<15)||(schedSore&&h>=15&&h<18);
  if(inWindow && (lastAuto==0 || millis()-lastAuto >= (unsigned long)sprayIntervalMin*60000UL)){
    lastAuto=millis(); startPump1For(sprayDefaultSec);
  }
}
void setup(){
  Serial.begin(115200);
  pinMode(PIN_TRIG,OUTPUT); pinMode(PIN_ECHO,INPUT);
  pinMode(PIN_PUMP1,OUTPUT); pinMode(PIN_PUMP2,OUTPUT);
  setPump1(false); setPump2(false);
  analogReadResolution(12);
  analogSetPinAttenuation(PIN_PH,ADC_11db); analogSetPinAttenuation(PIN_TDS,ADC_11db);
  dht.begin();
  WiFi.begin(WIFI_SSID,WIFI_PASS);
  Serial.print("Menghubungkan Wi-Fi");
  while(WiFi.status()!=WL_CONNECTED){delay(500);Serial.print('.');}
  configTime(7*3600,0,"pool.ntp.org","time.google.com");
  Serial.printf("\nWi-Fi OK, IP: %s\n",WiFi.localIP().toString().c_str());
}
void loop(){
  if(WiFi.status()!=WL_CONNECTED){WiFi.reconnect();delay(1000);return;}
  unsigned long now=millis();
  if(pump1Running && (long)(now-sprayEnd)>=0) setPump1(false);
  if(now-lastSend>=SEND_INTERVAL_MS){lastSend=now;sendReading();}
  if(now-lastCommand>=COMMAND_INTERVAL_MS){lastCommand=now;pollCommands();autoPumpSchedule();}
}
